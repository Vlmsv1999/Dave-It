#ifndef B43_WA_H_
#define B43_WA_H_

void b43_wa_initgains(struct b43_wldev *dev);
void b43_wa_all(struct b43_wldev *dev);

#endif /* B43_WA_H_ */
